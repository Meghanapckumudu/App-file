import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReturnpolicyPage } from './returnpolicy';

@NgModule({
  declarations: [
    ReturnpolicyPage,
  ],
  imports: [
    IonicPageModule.forChild(ReturnpolicyPage),
  ],
})
export class ReturnpolicyPageModule {}
