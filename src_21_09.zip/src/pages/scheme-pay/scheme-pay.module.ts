import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SchemePayPage } from './scheme-pay';

@NgModule({
  declarations: [
    SchemePayPage,
  ],
  imports: [
    IonicPageModule.forChild(SchemePayPage),
  ],
})
export class SchemePayPageModule {}
