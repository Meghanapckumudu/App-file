import { NgModule } from '@angular/core';
import { SettingsComponent } from './settings/settings';
@NgModule({
	declarations: [SettingsComponent],
	imports: [],
	exports: [SettingsComponent]
})
export class ComponentsModule {}
