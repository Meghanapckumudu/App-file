import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JoinChitPage } from './join-chit';

@NgModule({
  declarations: [
    JoinChitPage,
  ],
  imports: [
    IonicPageModule.forChild(JoinChitPage),
  ],
})
export class JoinChitPageModule {}
