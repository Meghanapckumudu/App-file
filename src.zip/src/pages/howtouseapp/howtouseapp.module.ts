import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HowtouseappPage } from './howtouseapp';

@NgModule({
  declarations: [
    HowtouseappPage,
  ],
  imports: [
    IonicPageModule.forChild(HowtouseappPage),
  ],
})
export class HowtouseappPageModule {}
