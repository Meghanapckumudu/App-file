import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TesteasypayPage } from './testeasypay';

@NgModule({
  declarations: [
    TesteasypayPage,
  ],
  imports: [
    IonicPageModule.forChild(TesteasypayPage),
  ],
})
export class TesteasypayPageModule {}
