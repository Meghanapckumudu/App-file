import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JoinChitSuccessPage } from './join-chit-success';

@NgModule({
  declarations: [
    JoinChitSuccessPage,
  ],
  imports: [
    IonicPageModule.forChild(JoinChitSuccessPage),
  ],
})
export class JoinChitSuccessPageModule {}
